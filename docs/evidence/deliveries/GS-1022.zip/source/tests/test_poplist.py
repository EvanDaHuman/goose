"""Focused checks for the new ``Headers.poplist`` method."""
from __future__ import annotations

import pytest

from werkzeug.datastructures import EnvironHeaders
from werkzeug.datastructures import Headers


def test_poplist_returns_all_values_in_order():
    h = Headers()
    h.add("X", "a")
    h.add("Y", "z")
    h.add("X", "b")
    h.add("X", "a")
    assert h.poplist("X") == ["a", "b", "a"]


def test_poplist_removes_all_occurrences_case_insensitive():
    h = Headers([("X-Foo", "1"), ("x-foo", "2"), ("Bar", "3"), ("X-FOO", "4")])
    assert h.poplist("x-FOO") == ["1", "2", "4"]
    assert list(h) == [("Bar", "3")]


def test_poplist_preserves_relative_order_of_unrelated():
    h = Headers(
        [
            ("A", "1"),
            ("B", "2"),
            ("A", "3"),
            ("C", "4"),
            ("A", "5"),
            ("D", "6"),
        ]
    )
    assert h.poplist("A") == ["1", "3", "5"]
    assert list(h) == [("B", "2"), ("C", "4"), ("D", "6")]


def test_poplist_empty_when_absent():
    h = Headers([("A", "1"), ("B", "2")])
    rv = h.poplist("C")
    assert rv == []
    assert list(h) == [("A", "1"), ("B", "2")]


def test_poplist_returns_independent_list():
    h = Headers([("X", "a"), ("X", "b")])
    rv = h.poplist("X")
    assert rv == ["a", "b"]
    rv.append("c")
    h.add("X", "d")
    assert rv == ["a", "b", "c"]
    assert h.getlist("X") == ["d"]


def test_poplist_empty_headers():
    h = Headers()
    assert h.poplist("X") == []


def test_poplist_docstring():
    assert Headers.poplist.__doc__ is not None
    assert "insertion order" in Headers.poplist.__doc__


def test_poplist_return_annotation_list_str():
    import typing

    # ``get_type_hints`` on the function should resolve the return to list[str]
    hints = typing.get_type_hints(Headers.poplist)
    assert hints.get("return") == list[str]


def test_poplist_on_environ_headers_raises_typeerror():
    environ = {
        "HTTP_X_FOO": "1",
        "HTTP_X_BAR": "2",
        "CONTENT_TYPE": "text/plain",
        "CONTENT_LENGTH": "5",
    }
    eh = EnvironHeaders(environ)
    with pytest.raises(TypeError):
        eh.poplist("X-Foo")
