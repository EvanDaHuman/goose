# Route planning engine to Node.js with blocked-link support

TEST engagement. No real customer or revenue is implied.

The source/ directory contains the verified implementation. Build using target_build from workspace-contract.json. All commands are argv arrays executed in the source directory. report.json records the checks and limitations. Preserve the original system before deployment. Production cutover and data reconciliation require a separately approved plan.
