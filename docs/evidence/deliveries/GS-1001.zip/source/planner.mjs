import { readFileSync } from "node:fs";

// Route planning core, ported from planner.py.  Uses only Node.js built-in
// modules.  Reads one JSON request object from stdin and writes one JSON
// response object to stdout.
//
// Behaviour preserved from the original Python program:
//   - unknown node error (checked before any edge validation)
//   - invalid edge error (unknown endpoint or non-numeric / negative weight)
//   - shortest undirected weighted route via Dijkstra
//   - lexicographic tie-break on equal-cost routes
//   - unreachable routes reported as {"distance": null, "route": []}
//   - Unicode node names and fractional distances (including emitting "5.0"
//     when a fractional sum happens to be a whole number, matching Python's
//     int/float distinction)
//
// New behaviour:
//   - optional "blocked_edges" field: a list of undirected [a, b] pairs that
//     must never be traversed, regardless of endpoint order.

// ---------------------------------------------------------------------------
// Tagged numbers.  JSON.parse loses the int/float distinction that Python's
// json preserves (2.0 stays a float, so 2.0 + 3.0 prints "5.0").  A tiny
// recursive-descent JSON parser below therefore wraps every numeric literal
// in a Num carrying an isFloat flag, so downstream arithmetic and output can
// reproduce Python's behaviour exactly.
// ---------------------------------------------------------------------------

class Num {
  constructor(value, isFloat) {
    this.value = value;
    this.isFloat = isFloat;
  }
}

function isNumLike(v) {
  return v instanceof Num || typeof v === "boolean";
}
// Python treats bool as an int subclass: True == 1, False == 0.
function numVal(v) {
  if (v instanceof Num) return v.value;
  if (typeof v === "boolean") return v ? 1 : 0;
  return v;
}
function numFloat(v) {
  if (v instanceof Num) return v.isFloat;
  return false;
}
function numAdd(a, b) {
  return new Num(numVal(a) + numVal(b), numFloat(a) || numFloat(b));
}
function numNonNeg(v) {
  return numVal(v) >= 0;
}
function numCmp(a, b) {
  const av = numVal(a);
  const bv = numVal(b);
  return av < bv ? -1 : av > bv ? 1 : 0;
}

// ---------------------------------------------------------------------------
// Minimal JSON parser.  Supports the subset this program needs: objects,
// arrays, strings (with escapes and surrogate pairs), numbers (tagged int vs
// float), true, false, null.  Throws SyntaxError on malformed input.
// ---------------------------------------------------------------------------

function parseJson(text) {
  let pos = 0;
  const n = text.length;

  function skipWs() {
    while (pos < n) {
      const c = text[pos];
      if (c === " " || c === "\t" || c === "\n" || c === "\r") pos++;
      else break;
    }
  }

  function parseValue() {
    skipWs();
    if (pos >= n) throw new SyntaxError("Unexpected end of input");
    const c = text[pos];
    if (c === "{") return parseObject();
    if (c === "[") return parseArray();
    if (c === '"') return parseString();
    if (c === "t") return parseLiteral("true", true);
    if (c === "f") return parseLiteral("false", false);
    if (c === "n") return parseLiteral("null", null);
    if (c === "-" || c >= "0" && c <= "9") return parseNumber();
    throw new SyntaxError("Unexpected character " + c);
  }

  function parseLiteral(lit, value) {
    if (text.substr(pos, lit.length) !== lit) throw new SyntaxError("Invalid literal");
    pos += lit.length;
    return value;
  }

  function parseObject() {
    pos++; // {
    skipWs();
    const obj = Object.create(null);
    if (text[pos] === "}") {
      pos++;
      return obj;
    }
    for (;;) {
      skipWs();
      if (text[pos] !== '"') throw new SyntaxError("Expected string key");
      const key = parseString();
      skipWs();
      if (text[pos] !== ":") throw new SyntaxError("Expected ':'");
      pos++;
      const value = parseValue();
      obj[key] = value;
      skipWs();
      const c = text[pos];
      if (c === ",") {
        pos++;
        continue;
      }
      if (c === "}") {
        pos++;
        break;
      }
      throw new SyntaxError("Expected ',' or '}'");
    }
    return obj;
  }

  function parseArray() {
    pos++; // [
    skipWs();
    const arr = [];
    if (text[pos] === "]") {
      pos++;
      return arr;
    }
    for (;;) {
      const value = parseValue();
      arr.push(value);
      skipWs();
      const c = text[pos];
      if (c === ",") {
        pos++;
        continue;
      }
      if (c === "]") {
        pos++;
        break;
      }
      throw new SyntaxError("Expected ',' or ']'");
    }
    return arr;
  }

  function parseString() {
    pos++; // opening "
    let result = "";
    while (pos < n) {
      const c = text[pos];
      if (c === '"') {
        pos++;
        return result;
      }
      if (c === "\\") {
        pos++;
        const esc = text[pos];
        pos++;
        switch (esc) {
          case '"': result += '"'; break;
          case "\\": result += "\\"; break;
          case "/": result += "/"; break;
          case "b": result += "\b"; break;
          case "f": result += "\f"; break;
          case "n": result += "\n"; break;
          case "r": result += "\r"; break;
          case "t": result += "\t"; break;
          case "u": {
            const hex = text.substr(pos, 4);
            if (hex.length < 4) throw new SyntaxError("Bad unicode escape");
            pos += 4;
            let code = parseInt(hex, 16);
            if (code >= 0xd800 && code <= 0xdbff) {
              // high surrogate; expect low surrogate
              if (text[pos] === "\\" && text[pos + 1] === "u") {
                const lo = text.substr(pos + 2, 4);
                if (lo.length < 4) throw new SyntaxError("Bad unicode escape");
                const loCode = parseInt(lo, 16);
                if (loCode >= 0xdc00 && loCode <= 0xdfff) {
                  pos += 6;
                  code = 0x10000 + ((code - 0xd800) << 10) + (loCode - 0xdc00);
                }
              }
            }
            result += String.fromCodePoint(code);
            break;
          }
          default: throw new SyntaxError("Bad escape \\" + esc);
        }
      } else if (c.charCodeAt(0) < 0x20) {
        throw new SyntaxError("Unescaped control character");
      } else {
        // copy raw UTF-8 byte sequence (string is UTF-8 decoded already)
        result += c;
        pos++;
      }
    }
    throw new SyntaxError("Unterminated string");
  }

  function parseNumber() {
    const start = pos;
    if (text[pos] === "-") pos++;
    if (text[pos] === "0") {
      pos++;
    } else if (text[pos] >= "1" && text[pos] <= "9") {
      while (pos < n && text[pos] >= "0" && text[pos] <= "9") pos++;
    } else {
      throw new SyntaxError("Invalid number");
    }
    let isFloat = false;
    if (text[pos] === ".") {
      isFloat = true;
      pos++;
      while (pos < n && text[pos] >= "0" && text[pos] <= "9") pos++;
    }
    if (text[pos] === "e" || text[pos] === "E") {
      isFloat = true;
      pos++;
      if (text[pos] === "+" || text[pos] === "-") pos++;
      while (pos < n && text[pos] >= "0" && text[pos] <= "9") pos++;
    }
    const token = text.slice(start, pos);
    const value = Number(token);
    if (!Number.isFinite(value)) throw new SyntaxError("Invalid number");
    return new Num(value, isFloat);
  }

  const result = parseValue();
  skipWs();
  if (pos !== n) throw new SyntaxError("Unexpected trailing content");
  return result;
}

// ---------------------------------------------------------------------------
// JSON serialisation with ensure_ascii=false semantics (raw UTF-8 output).
// ---------------------------------------------------------------------------

function jsonRepr(value) {
  if (value === null) return "null";
  if (value === true) return "true";
  if (value === false) return "false";
  if (value instanceof Num) {
    const v = value.value;
    if (!Number.isFinite(v)) return "null"; // Python json uses "NaN"/"Infinity" but those cannot arise here
    // Python: int -> "5", float -> "5.0".  Number.prototype.toString gives the
    // shortest round-tripping decimal for floats, matching Python's repr.
    if (value.isFloat) {
      const s = v.toString();
      if (s.indexOf(".") === -1 && s.indexOf("e") === -1 && s.indexOf("E") === -1) {
        return s + ".0";
      }
      return s;
    }
    return v.toString();
  }
  if (typeof value === "number") {
    if (Number.isFinite(value)) return value.toString();
    return "null";
  }
  if (typeof value === "string") return quoteString(value);
  if (Array.isArray(value)) {
    if (value.length === 0) return "[]";
    let out = "[";
    for (let i = 0; i < value.length; i++) {
      if (i > 0) out += ", ";
      out += jsonRepr(value[i]);
    }
    out += "]";
    return out;
  }
  // plain object
  {
    const keys = Object.keys(value);
    if (keys.length === 0) return "{}";
    let out = "{";
    for (let i = 0; i < keys.length; i++) {
      if (i > 0) out += ", ";
      out += quoteString(keys[i]) + ": " + jsonRepr(value[keys[i]]);
    }
    out += "}";
    return out;
  }
}

function quoteString(s) {
  let out = '"';
  for (let i = 0; i < s.length; i++) {
    const ch = s.charCodeAt(i);
    if (ch === 0x22) out += '\\"';
    else if (ch === 0x5c) out += "\\\\";
    else if (ch === 0x08) out += "\\b";
    else if (ch === 0x0c) out += "\\f";
    else if (ch === 0x0a) out += "\\n";
    else if (ch === 0x0d) out += "\\r";
    else if (ch === 0x09) out += "\\t";
    else if (ch < 0x20) out += "\\u" + ch.toString(16).padStart(4, "0");
    else out += s[i];
  }
  out += '"';
  return out;
}

// ---------------------------------------------------------------------------
// Route planning.
// ---------------------------------------------------------------------------

function plan(request) {
  if (request === null || typeof request !== "object" || Array.isArray(request)) {
    // Python raises AttributeError here, which is NOT caught by the CLI's
    // except clause -> the process aborts with a traceback and prints nothing
    // to stdout.  Mirror that by throwing an error the CLI will not catch.
    const err = new Error("request is not an object");
    err.plannerUncatchable = true;
    throw err;
  }

  const nodes = request.nodes !== undefined ? request.nodes : [];
  const start = request.start !== undefined ? request.start : undefined;
  const end = request.end !== undefined ? request.end : undefined;

  const nodeSet = new Set(nodes);
  if (!nodeSet.has(start) || !nodeSet.has(end)) {
    return { error: "unknown node" };
  }

  // Blocked edges, undirected and endpoint-order independent.
  const blocked = new Set();
  if (request.blocked_edges !== undefined) {
    for (const pair of request.blocked_edges) {
      if (Array.isArray(pair) && pair.length === 2) {
        const x = pair[0];
        const y = pair[1];
        if (x <= y) blocked.add(x + "\u0000" + y);
        else blocked.add(y + "\u0000" + x);
      }
    }
  }
  const isBlocked = (a, b) => {
    const key = a <= b ? a + "\u0000" + b : b + "\u0000" + a;
    return blocked.has(key);
  };

  // Adjacency list mirroring graph[a].append((b, weight)); (a, weight) reversed.
  const graph = new Map();
  for (const node of nodes) graph.set(node, []);

  const edges = request.edges !== undefined ? request.edges : [];
  for (const edge of edges) {
    if (!Array.isArray(edge) || edge.length < 3) return { error: "invalid edge" };
    const a = edge[0];
    const b = edge[1];
    const weight = edge[2];
    if (!graph.has(a) || !graph.has(b) || !isNumLike(weight) || !numNonNeg(weight)) {
      return { error: "invalid edge" };
    }
    graph.get(a).push([b, weight]);
    graph.get(b).push([a, weight]);
  }

  // Dijkstra over a binary heap.  Each heap entry is [distance, route, node].
  // heapq compares tuples element-wise: distance, then route (lexicographic on
  // the list of node strings), then node string.  The start distance is int 0.
  const startDist = new Num(0, false);
  const queue = [];
  queue.push([startDist, [start], start]);

  const best = new Map();
  while (queue.length > 0) {
    const [distance, route, node] = heapPop(queue);
    if (best.has(node)) continue;
    best.set(node, distance);
    if (node === end) {
      return { distance, route };
    }
    const neighbors = graph.get(node).slice();
    neighbors.sort(compareNeighbor);
    for (const [neighbor, weight] of neighbors) {
      if (!best.has(neighbor) && !isBlocked(node, neighbor)) {
        heapPush(queue, [numAdd(distance, weight), route.concat(neighbor), neighbor]);
      }
    }
  }
  return { distance: null, route: [] };
}

function compareNeighbor(a, b) {
  // a, b are [neighbor, weight]; Python sorts (neighbor, weight) tuples.
  if (a[0] < b[0]) return -1;
  if (a[0] > b[0]) return 1;
  return numCmp(a[1], b[1]);
}

// Tuple comparison matching Python's heapq: [distance, route, node].
function compareEntry(a, b) {
  const d = numCmp(a[0], b[0]);
  if (d !== 0) return d;
  const ar = a[1];
  const br = b[1];
  const len = Math.min(ar.length, br.length);
  for (let i = 0; i < len; i++) {
    if (ar[i] < br[i]) return -1;
    if (ar[i] > br[i]) return 1;
  }
  if (ar.length < br.length) return -1;
  if (ar.length > br.length) return 1;
  if (a[2] < b[2]) return -1;
  if (a[2] > b[2]) return 1;
  return 0;
}

function heapPush(queue, entry) {
  queue.push(entry);
  siftUp(queue, queue.length - 1);
}

function heapPop(queue) {
  const top = queue[0];
  const last = queue.pop();
  if (queue.length > 0) {
    queue[0] = last;
    siftDown(queue, 0);
  }
  return top;
}

function siftUp(queue, i) {
  while (i > 0) {
    const parent = (i - 1) >> 1;
    if (compareEntry(queue[i], queue[parent]) < 0) {
      const tmp = queue[i];
      queue[i] = queue[parent];
      queue[parent] = tmp;
      i = parent;
    } else break;
  }
}

function siftDown(queue, i) {
  const n = queue.length;
  for (;;) {
    const left = 2 * i + 1;
    const right = 2 * i + 2;
    let smallest = i;
    if (left < n && compareEntry(queue[left], queue[smallest]) < 0) smallest = left;
    if (right < n && compareEntry(queue[right], queue[smallest]) < 0) smallest = right;
    if (smallest === i) break;
    const tmp = queue[i];
    queue[i] = queue[smallest];
    queue[smallest] = tmp;
    i = smallest;
  }
}

// ---------------------------------------------------------------------------
// CLI entry point.  Mirrors planner.py's __main__ block: parse stdin, run
// plan, and on a parse error print {"error":"invalid request"}.  Errors that
// the Python source does not catch (e.g. AttributeError for non-object JSON)
// propagate and abort the process with no stdout, exactly as Python does.
// ---------------------------------------------------------------------------

function main() {
  let input;
  try {
    input = readFileSync(0, "utf8");
  } catch (_) {
    console.log(jsonRepr({ error: "invalid request" }));
    return;
  }

  let request;
  try {
    request = parseJson(input);
  } catch (_) {
    console.log(jsonRepr({ error: "invalid request" }));
    return;
  }

  let result;
  try {
    result = plan(request);
  } catch (e) {
    if (e && e.plannerUncatchable) throw e;
    // Python catches (ValueError, TypeError, KeyError); other errors abort.
    if (e instanceof TypeError || e instanceof SyntaxError) {
      console.log(jsonRepr({ error: "invalid request" }));
      return;
    }
    throw e;
  }
  console.log(jsonRepr(result));
}

main();
