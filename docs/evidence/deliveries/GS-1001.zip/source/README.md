# Route planner (Node.js)

`planner.mjs` is a command-line route planner ported from the original Python
program `planner.py` (kept for reference in `original/`). It finds the shortest
route between two nodes in an undirected weighted graph using Dijkstra's
algorithm, with a deterministic lexicographic tie-break on equal-cost routes.

It uses **only Node.js built-in modules** (`node:fs`) — no external
dependencies, no `npm install`.

## Running

Read one JSON request object from stdin; write one JSON response object to
stdout:

```sh
echo '{"nodes":["A","B","C"],"start":"A","end":"C","edges":[["A","B",2],["B","C",3]]}' | node planner.mjs
```

Output:

```json
{"distance": 5, "route": ["A", "B", "C"]}
```

### Request fields

| Field          | Type                    | Required | Description                                                  |
| -------------- | ----------------------- | -------- | ------------------------------------------------------------ |
| `nodes`        | array of strings        | no       | Known node names. Defaults to `[]`.                          |
| `start`        | string                  | yes      | Start node.                                                  |
| `end`          | string                  | yes      | Destination node.                                            |
| `edges`        | array of `[a,b,w]`      | no       | Undirected weighted edges. Defaults to `[]`.                 |
| `blocked_edges`| array of `[a,b]` pairs  | no       | Undirected pairs that must never be traversed. Defaults to `[]`. |

### Response

- On success: `{"distance": <number>, "route": [<node>, ...]}`.
- When the destination is unreachable (or every path to it is blocked):
  `{"distance": null, "route": []}`.
- On error: `{"error": "unknown node"}`, `{"error": "invalid edge"}`, or
  `{"error": "invalid request"}` (for non-JSON stdin).

## Preserved behavior (identical to `planner.py`)

- **Weighted routes**: Dijkstra over the undirected graph picks the
  minimum total weight.
- **Reverse routes**: the graph is undirected, so `start`↔`end` are
  symmetric.
- **Same node**: `start == end` returns `{"distance": 0, "route": [start]}`.
- **Tie-break**: when several routes have the same minimum cost, the
  lexicographically smaller route is returned (matching Python's `heapq`
  tuple comparison on `(distance, route, node)`).
- **Unknown node**: `{"error": "unknown node"}` if `start` or `end` is not in
  `nodes`. This is checked **before** any edge validation, exactly as in the
  Python source.
- **Disconnected / unreachable**: `{"distance": null, "route": []}`.
- **Invalid edge**: `{"error": "invalid edge"}` for an edge whose endpoints are
  not known nodes, or whose weight is not a non-negative number. Booleans are
  accepted as numbers (`true` → `1`, `false` → `0`), matching Python's
  `isinstance(weight, (int, float))` where `bool` is an `int` subclass.
- **Fractional distances**: floats are preserved. A fractional sum that is a
  whole number is emitted as a float (e.g. `2.5 + 2.5` → `"5.0"`), matching
  Python's int/float distinction.
- **Unicode**: node names may be any Unicode strings; output is emitted as raw
  UTF-8 (equivalent to Python's `ensure_ascii=False`).
- **Malformed stdin**: non-JSON input yields `{"error": "invalid request"}`.

## New behavior: `blocked_edges`

`blocked_edges` is an optional array of undirected `[a, b]` pairs. An edge is
blocked regardless of endpoint order, so `["A","C"]` and `["C","A"]` block the
same edge. A blocked edge is never traversed, even if it would otherwise be on
the shortest path; the planner then routes around it, or reports the
destination as unreachable if every path to it is blocked.

Example — the direct edge `A↔C` is blocked, so the route goes through `B`:

```sh
echo '{"nodes":["A","B","C"],"start":"A","end":"C","edges":[["A","C",1],["A","B",2],["B","C",1]],"blocked_edges":[["A","C"]]}' | node planner.mjs
```

Output:

```json
{"distance": 3, "route": ["A", "B", "C"]}
```

Blocking the only edge makes the destination unreachable:

```sh
echo '{"nodes":["A","B"],"start":"A","end":"B","edges":[["A","B",1]],"blocked_edges":[["A","B"]]}' | node planner.mjs
```

Output:

```json
{"distance": null, "route": []}
```

## Implementation notes

- The number int/float distinction that Python's `json` preserves (and that
  JS `JSON.parse` loses) is recovered by a small built-in JSON parser that
  tags numeric literals as int or float, so output like `5.0` is reproduced
  exactly.
- The binary heap and tuple comparator reproduce Python `heapq`'s ordering
  (distance, then route list lexicographically, then node string), so tie-break
  results match byte-for-byte.
- No external dependencies; only `node:fs` is imported. Run with Node.js 16+.
