#!/usr/bin/env python3
# -----------------------------------------------------------------------------
# goose_rrt_exploration / scripts / assigner.py
#
# ROS2 Jazzy migration of the MIT rrt_exploration assigner node.
# Original source: https://github.com/hasankhaiser/rrt_exploration
# Licensed under the MIT License (see README.md for full notice).
#
# The assigner selects the best frontier (information gain minus travel cost,
# with hysteresis bias toward the current exploration region) and dispatches a
# single NavigateToPose goal at a time to the existing Nav2 stack.
#
# Consumes:
#   /map              (nav_msgs/OccupancyGrid, transient-local QoS)
#   /filtered_points  (goose_rrt_exploration/PointArray)
#   TF  map -> base_link
#   navigate_to_pose  (nav2_msgs/NavigateToPose action)
#
# Publishes:
#   /goose/exploration_status  (std_msgs/String, JSON)
#
# Algorithm concepts ported from the original Python2 assigner:
#   - information gain per frontier (unknown cells within radius)
#   - travel cost (Euclidean distance to frontier)
#   - hysteresis gain for frontiers near the robot
#   - revenue = information_gain * info_multiplier - cost
#   - select maximum-revenue frontier
# -----------------------------------------------------------------------------

import json
import math

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy, HistoryPolicy
from rclpy.time import Time
from rclpy.duration import Duration

from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import PoseStamped
from std_msgs.msg import String
from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatus
from lifecycle_msgs.srv import GetState

from tf2_ros import Buffer, TransformListener, TransformException

from goose_rrt_exploration.msg import PointArray

# core.py lives beside this script and is importable without ROS or numpy.
import core


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------


def _distance(a, b):
    """Euclidean distance between two 2-D points given as indexable pairs."""
    return math.hypot(float(a[0]) - float(b[0]), float(a[1]) - float(b[1]))


def _normalize_frame(frame_id):
    """Strip a leading slash from a frame id (ROS2 convention)."""
    if frame_id and frame_id.startswith('/'):
        return frame_id[1:]
    return frame_id


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------


class AssignerNode(Node):
    """
    Frontier-assignment node for a single differential-drive robot.

    Uses bounded timer callbacks and fully async action / service calls so that
    no callback ever blocks.  A single NavigateToPose goal is active at any time;
    the result is awaited via ``get_result_async`` before dispatching the next.
    """

    def __init__(self):
        super().__init__('assigner')

        # ---- parameters (use_sim_time is declared by the Node base) ----
        self.declare_parameter('map_topic', '/map')
        self.declare_parameter('frontiers_topic', '/filtered_points')
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('robot_frame', 'base_link')
        self.declare_parameter('info_radius', 1.0)
        self.declare_parameter('info_multiplier', 3.0)
        self.declare_parameter('hysteresis_radius', 3.0)
        self.declare_parameter('hysteresis_gain', 2.0)
        self.declare_parameter('max_goals', 0)            # 0 = unlimited
        self.declare_parameter('random_seed', 0)
        self.declare_parameter('delay_after_assignment', 0.5)
        self.declare_parameter('dispatch_rate', 2.0)       # Hz
        self.declare_parameter('nav2_active_state', 3)    # lifecycle PRIMARY_STATE_ACTIVE
        self.declare_parameter('goal_timeout', 60.0)       # seconds; 0 = no timeout
        self.declare_parameter('lifecycle_check_rate', 1.0)
        self.declare_parameter('retry_delay', 2.0)

        self.map_topic = self.get_parameter('map_topic').value
        self.frontiers_topic = self.get_parameter('frontiers_topic').value
        self.global_frame = self.get_parameter('global_frame').value
        self.robot_frame = self.get_parameter('robot_frame').value
        self.info_radius = float(self.get_parameter('info_radius').value)
        self.info_multiplier = float(self.get_parameter('info_multiplier').value)
        self.hysteresis_radius = float(self.get_parameter('hysteresis_radius').value)
        self.hysteresis_gain = float(self.get_parameter('hysteresis_gain').value)
        self.max_goals = int(self.get_parameter('max_goals').value)
        self.delay_after_assignment = float(self.get_parameter('delay_after_assignment').value)
        self.dispatch_rate = float(self.get_parameter('dispatch_rate').value)
        self.nav2_active_state = int(self.get_parameter('nav2_active_state').value)
        self.goal_timeout = float(self.get_parameter('goal_timeout').value)
        self.lifecycle_check_rate = float(self.get_parameter('lifecycle_check_rate').value)
        self.retry_delay = float(self.get_parameter('retry_delay').value)

        # ---- runtime state ----
        self._map_data = None                 # latest OccupancyGrid
        self._map_frame = None                # normalised frame id from /map header
        self._frontiers = []                  # list of [x, y]
        self._goal_handle = None
        self._result_future = None
        self._goal_active = False
        self._completed_goals = 0
        self._failed_goals = 0
        self._selected_goal = None            # [x, y] or None
        self._assigned_point = None           # last sent goal [x, y]
        self._last_assignment_time = 0.0       # seconds (clock)
        self._goal_sent_time = 0.0             # seconds (clock)
        self._shutting_down = False
        self._nav2_active = False
        self._retry_timer = None

        # ---- TF2 ----
        self._tf_buffer = Buffer()
        self._tf_listener = TransformListener(self._tf_buffer, self)

        # ---- QoS: transient-local for /map (late-joining subscribers get
        #      the most recent map) ----
        map_qos = QoSProfile(
            depth=1,
            history=HistoryPolicy.KEEP_LAST,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=QoSReliabilityPolicy.RELIABLE,
        )

        # ---- subscribers ----
        self._map_sub = self.create_subscription(
            OccupancyGrid, self.map_topic, self._map_callback, map_qos)
        self._frontiers_sub = self.create_subscription(
            PointArray, self.frontiers_topic, self._frontiers_callback, 10)

        # ---- publishers ----
        self._status_pub = self.create_publisher(
            String, '/goose/exploration_status', 10)

        # ---- action client (NavigateToPose) ----
        self._action_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')

        # ---- lifecycle service client (bt_navigator) ----
        self._lifecycle_client = self.create_client(
            GetState, '/bt_navigator/get_state')

        # ---- timers (bounded, non-blocking callbacks) ----
        self._lifecycle_timer = self.create_timer(
            1.0 / max(self.lifecycle_check_rate, 0.1),
            self._lifecycle_check_callback)
        self._dispatch_timer = self.create_timer(
            1.0 / max(self.dispatch_rate, 0.1),
            self._dispatch_callback)

        self.get_logger().info(
            'Assigner started. map=%s frontiers=%s frame=%s robot=%s'
            % (self.map_topic, self.frontiers_topic,
               self.global_frame, self.robot_frame))
        self._publish_status()

    # ------------------------------------------------------------------
    # Subscriber callbacks
    # ------------------------------------------------------------------

    def _map_callback(self, msg):
        self._map_data = msg
        frame = _normalize_frame(msg.header.frame_id)
        self._map_frame = frame if frame else self.global_frame

    def _frontiers_callback(self, msg):
        self._frontiers = [[float(p.x), float(p.y)] for p in msg.points]

    # ------------------------------------------------------------------
    # Lifecycle check (async, non-blocking)
    # ------------------------------------------------------------------

    def _lifecycle_check_callback(self):
        if self._shutting_down:
            return
        if not self._lifecycle_client.service_is_ready():
            self._nav2_active = False
            return
        future = self._lifecycle_client.call_async(GetState.Request())
        future.add_done_callback(self._lifecycle_response_callback)

    def _lifecycle_response_callback(self, future):
        if self._shutting_down:
            return
        try:
            response = future.result()
            if response is not None and response.current_state is not None:
                self._nav2_active = (
                    response.current_state.id >= self.nav2_active_state)
            else:
                self._nav2_active = False
        except Exception as exc:
            self.get_logger().warn(
                'Lifecycle GetState call failed: %s' % exc,
                throttle_duration_sec=5.0)
            self._nav2_active = False

    # ------------------------------------------------------------------
    # TF helper (bounded, non-blocking)
    # ------------------------------------------------------------------

    def _get_robot_position(self):
        """Return [x, y] of the robot in the global frame, or None."""
        if self._shutting_down:
            return None
        try:
            trans = self._tf_buffer.lookup_transform(
                self.global_frame,
                self.robot_frame,
                Time(),
                timeout=Duration(seconds=0.1))
            t = trans.transform.translation
            return [float(t.x), float(t.y)]
        except TransformException as exc:
            self.get_logger().warn(
                'TF lookup %s -> %s failed: %s'
                % (self.global_frame, self.robot_frame, exc),
                throttle_duration_sec=3.0)
            return None
        except Exception as exc:
            self.get_logger().warn(
                'Unexpected TF error: %s' % exc, throttle_duration_sec=3.0)
            return None

    # ------------------------------------------------------------------
    # Dispatch timer (bounded, non-blocking)
    # ------------------------------------------------------------------

    def _dispatch_callback(self):
        if self._shutting_down:
            return

        # 1. Action server available?
        if not self._action_client.server_is_ready():
            return

        # 2. Nav2 lifecycle in the active state?
        if not self._nav2_active:
            self.get_logger().info(
                'Waiting for Nav2 bt_navigator to reach active lifecycle state %d.'
                % self.nav2_active_state,
                throttle_duration_sec=5.0)
            return

        # 3. A goal is already active -- check timeout, otherwise wait.
        if self._goal_active:
            if self.goal_timeout > 0 and self._goal_sent_time > 0:
                now_sec = self._clock_seconds()
                if (now_sec - self._goal_sent_time) > self.goal_timeout:
                    self.get_logger().warn(
                        'Goal timeout (%.1f s) reached; cancelling.'
                        % self.goal_timeout)
                    self._cancel_active_goal()
            return

        # 4. Max-goals limit.
        if self.max_goals > 0 and self._completed_goals >= self.max_goals:
            self.get_logger().info(
                'max_goals (%d) reached; stopping dispatch.' % self.max_goals,
                throttle_duration_sec=10.0)
            return

        # 5. Need a map and at least one frontier.
        if self._map_data is None or len(self._map_data.data) < 1:
            return
        if len(self._frontiers) < 1:
            return

        # 6. Respect delay after the previous assignment.
        now_sec = self._clock_seconds()
        if (now_sec - self._last_assignment_time) < self.delay_after_assignment:
            return

        # 7. Need robot position via TF.
        position = self._get_robot_position()
        if position is None:
            return

        # 8. Select the best frontier via core.select_goal
        #    (information gain - travel cost + hysteresis, deterministic ties).
        try:
            chosen = core.select_goal(
                self._map_data,
                position,
                self._frontiers,
                info_radius=self.info_radius,
                info_multiplier=self.info_multiplier,
                hysteresis_radius=self.hysteresis_radius,
                hysteresis_gain=self.hysteresis_gain,
            )
        except Exception as exc:
            self.get_logger().warn(
                'select_goal raised: %s' % exc, throttle_duration_sec=3.0)
            return

        if chosen is None:
            self._publish_status()
            return

        # 9. Send the NavigateToPose goal asynchronously.
        self._send_goal(chosen)

    # ------------------------------------------------------------------
    # Action goal send / response / result (all async)
    # ------------------------------------------------------------------

    def _send_goal(self, point):
        if self._shutting_down or self._goal_active:
            return

        frame = self._map_frame if self._map_frame else self.global_frame

        goal_pose = PoseStamped()
        goal_pose.header.frame_id = frame
        goal_pose.header.stamp = self.get_clock().now().to_msg()
        goal_pose.pose.position.x = float(point[0])
        goal_pose.pose.position.y = float(point[1])
        goal_pose.pose.position.z = 0.0
        goal_pose.pose.orientation.w = 1.0

        goal_msg = NavigateToPose.Goal()
        goal_msg.pose = goal_pose

        self._selected_goal = [float(point[0]), float(point[1])]
        self._assigned_point = [float(point[0]), float(point[1])]
        self._goal_active = True
        self._goal_sent_time = self._clock_seconds()
        self._last_assignment_time = self._goal_sent_time

        self.get_logger().info(
            'Dispatching NavigateToPose to [%.3f, %.3f] in frame %s'
            % (point[0], point[1], frame))
        self._publish_status()

        try:
            send_future = self._action_client.send_goal_async(goal_msg)
            send_future.add_done_callback(self._goal_response_callback)
        except Exception as exc:
            self.get_logger().error('send_goal_async failed: %s' % exc)
            self._goal_active = False
            self._failed_goals += 1
            self._selected_goal = None
            self._publish_status()
            self._schedule_retry()

    def _goal_response_callback(self, future):
        if self._shutting_down:
            self._goal_active = False
            return
        try:
            goal_handle = future.result()
        except Exception as exc:
            self.get_logger().error('Goal send future failed: %s' % exc)
            self._goal_active = False
            self._failed_goals += 1
            self._selected_goal = None
            self._publish_status()
            self._schedule_retry()
            return

        if goal_handle is None or not goal_handle.accepted:
            self.get_logger().warn(
                'NavigateToPose goal rejected; will retry after %.1f s.'
                % self.retry_delay)
            self._goal_active = False
            self._failed_goals += 1
            self._selected_goal = None
            self._publish_status()
            self._schedule_retry()
            return

        self._goal_handle = goal_handle
        self._result_future = goal_handle.get_result_async()
        self._result_future.add_done_callback(self._result_callback)

    def _result_callback(self, future):
        if self._shutting_down:
            self._goal_active = False
            self._goal_handle = None
            self._result_future = None
            return
        try:
            wrapped = future.result()
            status = wrapped.status if wrapped is not None else None
        except Exception as exc:
            self.get_logger().error('Goal result future failed: %s' % exc)
            status = None

        if status == GoalStatus.STATUS_SUCCEEDED:
            self._completed_goals += 1
            self.get_logger().info(
                'Goal SUCCEEDED  (completed=%d, failed=%d)'
                % (self._completed_goals, self._failed_goals))
        else:
            self._failed_goals += 1
            self.get_logger().warn(
                'Goal ended with status %s  (completed=%d, failed=%d)'
                % (status, self._completed_goals, self._failed_goals))

        self._goal_active = False
        self._goal_handle = None
        self._result_future = None
        self._selected_goal = None
        self._publish_status()

    # ------------------------------------------------------------------
    # Goal cancellation
    # ------------------------------------------------------------------

    def _cancel_active_goal(self):
        if self._goal_handle is not None:
            try:
                cancel_future = self._goal_handle.cancel_goal_async()
                cancel_future.add_done_callback(self._cancel_done_callback)
            except Exception as exc:
                self.get_logger().warn('cancel_goal_async failed: %s' % exc)
                self._goal_active = False
                self._goal_handle = None
        else:
            self._goal_active = False

    def _cancel_done_callback(self, future):
        try:
            future.result()
            self.get_logger().info('Goal cancel request accepted.')
        except Exception as exc:
            self.get_logger().warn('Goal cancel future error: %s' % exc)
        # The final status will arrive via _result_callback (STATUS_CANCELED).

    # ------------------------------------------------------------------
    # Retry (rejected / failed goals)
    # ------------------------------------------------------------------

    def _schedule_retry(self):
        if self._retry_timer is not None:
            try:
                self._retry_timer.cancel()
            except Exception:
                pass
            self._retry_timer = None
        self._retry_timer = self.create_timer(
            max(self.retry_delay, 0.1), self._retry_callback)

    def _retry_callback(self):
        if self._retry_timer is not None:
            try:
                self._retry_timer.cancel()
            except Exception:
                pass
            self._retry_timer = None
        if self._shutting_down or self._goal_active:
            return
        # Attempt a fresh dispatch immediately.
        self._dispatch_callback()

    # ------------------------------------------------------------------
    # Status publisher
    # ------------------------------------------------------------------

    def _publish_status(self):
        msg = String()
        payload = {
            'completed_goals': self._completed_goals,
            'failed_goals': self._failed_goals,
            'selected_goal': self._selected_goal,
        }
        msg.data = json.dumps(payload)
        self._status_pub.publish(msg)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _clock_seconds(self):
        return self.get_clock().now().nanoseconds / 1e9

    # ------------------------------------------------------------------
    # Shutdown
    # ------------------------------------------------------------------

    def shutdown(self):
        """Cancel any active goal and stop dispatching.  Idempotent."""
        if self._shutting_down:
            return
        self._shutting_down = True
        self.get_logger().info('Shutting down assigner.')
        if self._goal_active and self._goal_handle is not None:
            self.get_logger().info('Cancelling active goal on shutdown.')
            try:
                self._goal_handle.cancel_goal_async()
            except Exception as exc:
                self.get_logger().warn('Shutdown cancel failed: %s' % exc)
        self._goal_active = False
        self._goal_handle = None
        self._result_future = None
        self._selected_goal = None
        self._publish_status()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------


def main(args=None):
    rclpy.init(args=args)
    node = AssignerNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
