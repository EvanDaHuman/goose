#!/usr/bin/env python3
# core.py -- Pure-Python algorithm core for goose_rrt_exploration.
#
# Ported from the MIT-licensed rrt_exploration ROS1 package (original author:
# Hriday Bavle, rrt_exploration).  This module is importable WITHOUT ROS or
# numpy; it operates on plain Python map-like objects and returns plain Python
# numbers and lists.
#
# Copyright (c) MIT -- original rrt_exploration authors.
# Licensed under the BSD-3-Clause license.
#
# Map objects are expected to expose:
#   mapData.info.width            (int)
#   mapData.info.height           (int)
#   mapData.info.resolution       (float, > 0)
#   mapData.info.origin.position.x / .y   (float)
#   mapData.data                  (list[int]: -1 unknown, 0 free, 100 occupied)

import math


# ---------------------------------------------------------------------------
# Small helpers (replace numpy floor / norm / array)
# ---------------------------------------------------------------------------

def _distance(a, b):
    """Euclidean distance between two indexable 2D points [x, y]."""
    return math.sqrt((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2)


def _resolution(mapData):
    """Return a validated, strictly-positive map resolution."""
    res = mapData.info.resolution
    if res is None or res <= 0:
        raise ValueError("invalid map resolution")
    return res


# ---------------------------------------------------------------------------
# Coordinate / index helpers
# ---------------------------------------------------------------------------

def index_of_point(mapData, Xp):
    """Return the linear cell index for world coordinate Xp = [x, y].

    Preserves the original algorithm's floor-based indexing.
    """
    resolution = _resolution(mapData)
    Xstartx = mapData.info.origin.position.x
    Xstarty = mapData.info.origin.position.y
    width = mapData.info.width
    index = int(math.floor((Xp[1] - Xstarty) / resolution)) * width + \
        int(math.floor((Xp[0] - Xstartx) / resolution))
    return index


def point_of_index(mapData, i):
    """Return cell-corner world coordinates [x, y] for linear index i.

    Preserves the original Python2 integer-division semantics: the row is
    i // width and the column remainder is i - (i // width) * width.
    """
    width = mapData.info.width
    res = _resolution(mapData)
    row = i // width
    col = i - row * width
    y = mapData.info.origin.position.y + row * res
    x = mapData.info.origin.position.x + col * res
    return [x, y]


def gridValue(mapData, Xp):
    """Return the occupancy value at world point Xp.

    OccupancyGrid convention: 100 occupied, -1 unknown, 0 free.
    Out-of-bounds coordinates return 100 (treated as occupied/invalid) so
    that callers never act on cells outside the map.
    """
    res = _resolution(mapData)
    Xstartx = mapData.info.origin.position.x
    Xstarty = mapData.info.origin.position.y
    width = mapData.info.width
    data = mapData.data
    index = int(math.floor((Xp[1] - Xstarty) / res)) * width + \
        int(math.floor((Xp[0] - Xstartx) / res))
    if 0 <= int(index) < len(data):
        return data[int(index)]
    return 100


# ---------------------------------------------------------------------------
# Information gain and discounting
# ---------------------------------------------------------------------------

def informationGain(mapData, point, r):
    """Count unknown cells within radius r of *point* and return the area.

    A cell is counted when its data value is -1 (unknown) and its cell-corner
    coordinate is within Euclidean distance r of *point*.  The total count is
    multiplied by resolution squared to yield an area estimate.
    """
    res = _resolution(mapData)
    width = mapData.info.width
    data = mapData.data
    if not data:
        return 0.0
    infoGain = 0
    index = index_of_point(mapData, point)
    r_region = int(r / res)
    init_index = index - r_region * (width + 1)
    for n in range(0, 2 * r_region + 1):
        start = n * width + init_index
        end = start + 2 * r_region
        # Python2 integer division preserved via //
        limit = ((start // width) + 2) * width
        for i in range(start, end + 1):
            if 0 <= i < limit and i < len(data):
                if data[i] == -1 and \
                        _distance(point, point_of_index(mapData, i)) <= r:
                    infoGain += 1
    return infoGain * (res ** 2)


def discount(mapData, assigned_pt, centroids, infoGain, r):
    """Subtract 1 from infoGain[j] for every unknown cell near both
    assigned_pt and centroids[j].

    The original algorithm subtracts 1 per overlapping unknown cell (not the
    cell area); that behaviour is preserved here.  The *infoGain* list is
    modified in place and also returned.
    """
    if not centroids or infoGain is None:
        return infoGain
    res = _resolution(mapData)
    width = mapData.info.width
    data = mapData.data
    if not data:
        return infoGain
    index = index_of_point(mapData, assigned_pt)
    r_region = int(r / res)
    init_index = index - r_region * (width + 1)
    for n in range(0, 2 * r_region + 1):
        start = n * width + init_index
        end = start + 2 * r_region
        limit = ((start // width) + 2) * width
        for i in range(start, end + 1):
            if 0 <= i < limit and i < len(data):
                for j in range(0, len(centroids)):
                    current_pt = centroids[j]
                    if (data[i] == -1 and
                            _distance(point_of_index(mapData, i),
                                      current_pt) <= r and
                            _distance(point_of_index(mapData, i),
                                      assigned_pt) <= r):
                        infoGain[j] -= 1
    return infoGain


# ---------------------------------------------------------------------------
# Path cost
# ---------------------------------------------------------------------------

def pathCost(path):
    """Estimate path cost as the midpoint segment length times (len - 1).

    Preserves the original Python2 integer division len(path) // 2.
    Returns float('inf') for an empty path.
    """
    if len(path) > 0:
        i = len(path) // 2
        p1 = [path[i - 1].pose.position.x, path[i - 1].pose.position.y]
        p2 = [path[i].pose.position.x, path[i].pose.position.y]
        return _distance(p1, p2) * (len(path) - 1)
    return float('inf')


# ---------------------------------------------------------------------------
# Goal selection
# ---------------------------------------------------------------------------

def select_goal(mapData, position, frontiers, info_radius=1.0,
                info_multiplier=3.0, hysteresis_radius=3.0,
                hysteresis_gain=2.0):
    """Select the best frontier goal by information gain minus travel cost
    with hysteresis applied to nearby frontiers.

    Each frontier is scored as:
        score = effective_gain * info_multiplier - travel_cost
    where *travel_cost* is the Euclidean distance from *position* to the
    frontier, and *effective_gain* is the frontier's information gain
    multiplied by *hysteresis_gain* when the frontier lies within
    *hysteresis_radius* of *position* (hysteresis: prefer the frontier the
    robot is already close to).

    Frontiers that fall in occupied cells or outside the map (gridValue ==
    100) are ignored.

    The maximum score is selected.  Ties are resolved deterministically in
    favour of the earliest frontier in the input list (first-wins).

    Returns the chosen [x, y] or None when no valid frontier remains.
    """
    if not frontiers:
        return None

    best_score = None
    best_goal = None

    for frontier in frontiers:
        if frontier is None or len(frontier) < 2:
            continue

        # Skip occupied cells and out-of-map points (both yield 100).
        if gridValue(mapData, frontier) == 100:
            continue

        ig = informationGain(mapData, frontier, info_radius)
        travel_cost = _distance(position, frontier)

        if travel_cost <= hysteresis_radius:
            ig = ig * hysteresis_gain

        score = ig * info_multiplier - travel_cost

        # Strict > keeps the first frontier on ties (deterministic).
        if best_score is None or score > best_score:
            best_score = score
            best_goal = frontier

    if best_goal is None:
        return None
    return [best_goal[0], best_goal[1]]
