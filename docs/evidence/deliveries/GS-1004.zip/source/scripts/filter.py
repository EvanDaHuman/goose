#!/usr/bin/env python3
#
# filter.py — Frontier filtering node for goose_rrt_exploration (ROS2 Jazzy).
#
# Original rrt_exploration Copyright (c) MIT
#   https://github.com/hasauino/rrt_exploration
# Licensed under the MIT License.
#
# Migrated from the MIT ROS1 rrt_exploration package.  This node consumes
# /detected_points (geometry_msgs/PointStamped) produced by the RRT detector
# and /map (nav_msgs/OccupancyGrid).  It clusters the raw frontier candidates
# with mean-shift (numpy, no external ML dependency), removes candidates that
# are occupied in the costmap/map or carry low information gain, and publishes
# the survivors on /filtered_points as goose_rrt_exploration/PointArray.
#
# Algorithm preserved from the original filter.py:
#   1. Accumulate transformed frontier points in the map frame.
#   2. Mean-shift cluster the accumulated set; replace the set with centroids.
#   3. Drop centroids whose grid cell value exceeds the clearing threshold
#      (occupied / invalid) or whose information gain is below the minimum.
#   4. Publish the remaining centroids as PointArray.
#
# All processing happens inside a bounded timer callback — no blocking loops.

import threading

import numpy as np

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, QoSDurabilityPolicy, QoSReliabilityPolicy
from nav_msgs.msg import OccupancyGrid
from geometry_msgs.msg import Point, PointStamped
from visualization_msgs.msg import Marker
from tf2_ros import Buffer, TransformListener, TransformException

# Register geometry_msgs/PointStamped (and Point) with tf2 so that
# Buffer.transform() accepts PointStamped messages.  On ROS2 Jazzy this
# side-effect import is required; without it every PointStamped transform
# raises "Type PointStamped is not loaded or supported".
import tf2_geometry_msgs  # noqa: F401  (registration side effects)

import core
from goose_rrt_exploration.msg import PointArray


# ---------------------------------------------------------------------------
# Mean-shift clustering (numpy replacement for the original cluster routine)
# ---------------------------------------------------------------------------
def mean_shift(points, bandwidth=0.3, max_iter=20, tol=1e-3):
    """Simple mean-shift clustering using a flat kernel.

    Returns an ``(N, 2)`` float array of cluster centroids.  Deterministic:
    points are processed in input order and modes are merged greedily, so the
    output is reproducible for identical input.
    """
    pts = np.asarray(points, dtype=float)
    if pts.ndim == 1:
        pts = pts.reshape(1, -1)
    if pts.shape[0] == 0:
        return np.empty((0, pts.shape[1] if pts.ndim > 1 else 2))
    if pts.shape[0] == 1:
        return pts.copy()

    bw = bandwidth if bandwidth > 0 else 1e-6
    modes = []
    for p in pts:
        current = p.copy()
        for _ in range(max_iter):
            dists = np.linalg.norm(pts - current, axis=1)
            in_band = pts[dists <= bw]
            if in_band.shape[0] == 0:
                break
            new_mean = in_band.mean(axis=0)
            shift = np.linalg.norm(new_mean - current)
            current = new_mean
            if shift < tol:
                break
        modes.append(current)

    # Merge near-duplicate modes (within half the bandwidth).
    merged = []
    for c in modes:
        is_dup = False
        for m in merged:
            if np.linalg.norm(c - m) < bw * 0.5:
                is_dup = True
                break
        if not is_dup:
            merged.append(c)

    if not merged:
        return np.empty((0, pts.shape[1]))
    return np.array(merged, dtype=float)


# ---------------------------------------------------------------------------
# Node
# ---------------------------------------------------------------------------
class FilterNode(Node):
    def __init__(self):
        super().__init__('filter')

        # -- Parameters (use_sim_time is declared by the ROS2 Node base) -----
        self.declare_parameter('map_topic', '/map')
        self.declare_parameter('points_topic', '/detected_points')
        self.declare_parameter('frontiers_topic', '/filtered_points')
        self.declare_parameter('costmap_topic', '')
        self.declare_parameter('costmap_clearing_threshold', 70)
        self.declare_parameter('info_radius', 1.0)
        self.declare_parameter('rate', 10.0)
        self.declare_parameter('robot_frame', 'base_link')
        self.declare_parameter('global_frame', 'map')
        self.declare_parameter('cluster_bandwidth', 0.3)
        self.declare_parameter('min_info_gain', 0.2)

        self._map_topic = self.get_parameter('map_topic').value
        self._points_topic = self.get_parameter('points_topic').value
        self._frontiers_topic = self.get_parameter('frontiers_topic').value
        self._costmap_topic = self.get_parameter('costmap_topic').value
        self._threshold = self.get_parameter('costmap_clearing_threshold').value
        self._info_radius = float(self.get_parameter('info_radius').value)
        self._rate = float(self.get_parameter('rate').value)
        self._robot_frame = self.get_parameter('robot_frame').value
        self._global_frame = self.get_parameter('global_frame').value
        self._bandwidth = float(self.get_parameter('cluster_bandwidth').value)
        self._min_info_gain = float(self.get_parameter('min_info_gain').value)

        # -- State -----------------------------------------------------------
        self._lock = threading.Lock()
        self._map_data = OccupancyGrid()
        self._costmap_data = OccupancyGrid()
        self._frontiers = np.empty((0, 2), dtype=float)
        self._map_frame = None  # derived from /map header, no leading slash

        # -- TF2 -------------------------------------------------------------
        self._tf_buffer = Buffer()
        self._tf_listener = TransformListener(self._tf_buffer, self)

        # -- Subscribers ------------------------------------------------------
        # /map: transient-local QoS to match latched SLAM map publishers.
        map_qos = QoSProfile(
            depth=1,
            durability=QoSDurabilityPolicy.TRANSIENT_LOCAL,
            reliability=QoSReliabilityPolicy.RELIABLE,
        )
        self.create_subscription(
            OccupancyGrid, self._map_topic, self._map_callback, map_qos)

        if self._costmap_topic:
            self.create_subscription(
                OccupancyGrid, self._costmap_topic,
                self._costmap_callback, 10)

        self.create_subscription(
            PointStamped, self._points_topic, self._points_callback, 10)

        # -- Publishers ------------------------------------------------------
        self._filter_pub = self.create_publisher(
            PointArray, self._frontiers_topic, 10)
        self._frontier_marker_pub = self.create_publisher(
            Marker, 'frontiers', 10)
        self._centroid_marker_pub = self.create_publisher(
            Marker, 'centroids', 10)

        # -- Timer ------------------------------------------------------------
        period = 1.0 / max(self._rate, 0.1)
        self.create_timer(period, self._timer_callback)

        self.get_logger().info(
            'filter node ready: map=%s points=%s out=%s'
            % (self._map_topic, self._points_topic, self._frontiers_topic))

    # ------------------------------------------------------------------
    # Subscribers
    # ------------------------------------------------------------------
    def _map_callback(self, msg):
        with self._lock:
            self._map_data = msg
            frame = msg.header.frame_id
            if frame.startswith('/'):
                frame = frame[1:]
            self._map_frame = frame

    def _costmap_callback(self, msg):
        with self._lock:
            self._costmap_data = msg

    def _points_callback(self, msg):
        # Cannot transform until we know the target (map) frame.
        with self._lock:
            target = self._map_frame
        if target is None:
            return

        # Transform the incoming PointStamped into the map frame.
        # Non-blocking: if TF is unavailable, skip the point.
        try:
            transformed = self._tf_buffer.transform(
                msg, target, timeout=rclpy.duration.Duration(seconds=0.0))
        except TransformException as ex:
            self.get_logger().warn(
                'Skipping frontier point — TF unavailable: %s' % ex,
                throttle_duration_sec=2.0)
            return
        except Exception as ex:  # pragma: no cover — defensive
            self.get_logger().warn(
                'Skipping frontier point — transform error: %s' % ex,
                throttle_duration_sec=2.0)
            return

        pt = np.array(
            [[float(transformed.point.x), float(transformed.point.y)]],
            dtype=float)
        with self._lock:
            if self._frontiers.shape[0] > 0:
                self._frontiers = np.vstack((self._frontiers, pt))
            else:
                self._frontiers = pt

    # ------------------------------------------------------------------
    # Timer (bounded — no blocking waits)
    # ------------------------------------------------------------------
    def _timer_callback(self):
        with self._lock:
            if len(self._map_data.data) < 1:
                self.get_logger().info(
                    'Waiting for the map', throttle_duration_sec=2.0)
                return
            if self._frontiers.shape[0] < 1:
                return

            front = self._frontiers.copy()
            map_data = self._map_data
            costmap = self._costmap_data
            map_frame = self._map_frame

        # ---- Clustering ------------------------------------------------
        if front.shape[0] > 1:
            centroids = mean_shift(front, bandwidth=self._bandwidth)
        elif front.shape[0] == 1:
            centroids = front.copy()
        else:
            centroids = np.empty((0, 2))

        # Replace accumulated frontiers with the cluster centres (as in
        # the original: frontiers = copy(centroids)).
        with self._lock:
            if centroids.shape[0] > 0:
                self._frontiers = centroids.copy()
            else:
                self._frontiers = np.empty((0, 2))

        # ---- Clearing old / occupied / low-info frontiers -------------
        valid = []
        for c in centroids:
            x, y = float(c[0]), float(c[1])

            # Use the dedicated costmap if one is configured and has data;
            # otherwise fall back to the SLAM /map.
            if len(costmap.data) > 0:
                grid_val = core.gridValue(costmap, [x, y])
            else:
                grid_val = core.gridValue(map_data, [x, y])

            info_gain = core.informationGain(
                map_data, [x, y], self._info_radius * 0.5)

            if grid_val > self._threshold or info_gain < self._min_info_gain:
                continue
            valid.append([x, y])

        valid_arr = np.array(valid, dtype=float) if valid else np.empty((0, 2))

        # ---- Publish ---------------------------------------------------
        self._publish_filtered(valid_arr, map_frame)
        self._publish_markers(valid_arr, map_frame)

    # ------------------------------------------------------------------
    # Publishing
    # ------------------------------------------------------------------
    def _publish_filtered(self, centroids, frame_id):
        if frame_id is None:
            return

        # PointArray carries only geometry_msgs/Point[] points per the
        # approved message definition (no header), so the frame id is not
        # attached here; downstream consumers resolve the frame from /map.
        msg = PointArray()
        for c in centroids:
            pt = Point()
            pt.x = float(c[0])
            pt.y = float(c[1])
            pt.z = 0.0
            msg.points.append(pt)
        self._filter_pub.publish(msg)

    def _publish_markers(self, centroids, frame_id):
        if frame_id is None:
            return

        stamp = self.get_clock().now().to_msg()

        # All accumulated frontiers (pre-filtering) — yellow.
        frontier_marker = Marker()
        frontier_marker.header.frame_id = frame_id
        frontier_marker.header.stamp = stamp
        frontier_marker.ns = 'markers2'
        frontier_marker.id = 0
        frontier_marker.type = Marker.POINTS
        frontier_marker.action = Marker.ADD
        frontier_marker.pose.orientation.w = 1.0
        frontier_marker.scale.x = 0.2
        frontier_marker.scale.y = 0.2
        frontier_marker.color.r = 1.0
        frontier_marker.color.g = 1.0
        frontier_marker.color.b = 0.0
        frontier_marker.color.a = 1.0
        with self._lock:
            for f in self._frontiers:
                p = Point()
                p.x = float(f[0])
                p.y = float(f[1])
                p.z = 0.0
                frontier_marker.points.append(p)
        self._frontier_marker_pub.publish(frontier_marker)

        # Valid centroids (post-filtering) — green.
        centroid_marker = Marker()
        centroid_marker.header.frame_id = frame_id
        centroid_marker.header.stamp = stamp
        centroid_marker.ns = 'markers3'
        centroid_marker.id = 4
        centroid_marker.type = Marker.POINTS
        centroid_marker.action = Marker.ADD
        centroid_marker.pose.orientation.w = 1.0
        centroid_marker.scale.x = 0.2
        centroid_marker.scale.y = 0.2
        centroid_marker.color.r = 0.0
        centroid_marker.color.g = 1.0
        centroid_marker.color.b = 0.0
        centroid_marker.color.a = 1.0
        for c in centroids:
            p = Point()
            p.x = float(c[0])
            p.y = float(c[1])
            p.z = 0.0
            centroid_marker.points.append(p)
        self._centroid_marker_pub.publish(centroid_marker)


# ---------------------------------------------------------------------------
def main(args=None):
    rclpy.init(args=args)
    node = FilterNode()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
