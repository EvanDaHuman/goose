// SPDX-License-Identifier: MIT
//
// rrt_detector.cpp — ROS2 Jazzy port of the MIT rrt_exploration
// global_rrt_detector frontier detector.
//
// Original source (MIT License):
//   rrt_exploration by Hossam A. Abdelhafiz et al.
//   https://github.com/hasauino/rrt_exploration
//
// The RRT sampling, Nearest, Steer, and ObstacleFree logic is preserved
// from the original C++ source. The ROS1 blocking loop is replaced by a
// bounded timer callback that performs one RRT iteration per tick.
// The initial sampling region is derived from the received OccupancyGrid
// metadata instead of requiring five rviz clicked points, and the RRT is
// seeded from the robot pose obtained via tf2 (map -> base_link), falling
// back to the map centre when TF is unavailable.

#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <geometry_msgs/msg/point_stamped.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <visualization_msgs/msg/marker.hpp>

#include <tf2_ros/buffer.h>
#include <tf2_ros/transform_listener.h>
#include <tf2/exceptions.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <random>
#include <string>
#include <vector>

// ---------------------------------------------------------------------------
// Helper functions (ported from the original src/functions.cpp)
// ---------------------------------------------------------------------------

// Norm: Euclidean distance between two 2-D points.
static double Norm(const std::vector<double>& x1, const std::vector<double>& x2)
{
  return std::sqrt(std::pow(x2[0] - x1[0], 2) + std::pow(x2[1] - x1[1], 2));
}

// sign: returns -1.0 for negative input, +1.0 otherwise (original semantics).
static double sign(double n)
{
  if (n < 0.0) {
    return -1.0;
  }
  return 1.0;
}

// Nearest: returns the vertex in V closest to x (original semantics).
static std::vector<double> Nearest(
  const std::vector<std::vector<double>>& V,
  const std::vector<double>& x)
{
  double min = Norm(V[0], x);
  int min_index = 0;
  for (int j = 0; j < static_cast<int>(V.size()); j++) {
    double temp = Norm(V[j], x);
    if (temp <= min) {
      min = temp;
      min_index = j;
    }
  }
  return V[min_index];
}

// Steer: moves from x_nearest toward x_rand by at most eta (original logic).
static std::vector<double> Steer(
  const std::vector<double>& x_nearest,
  const std::vector<double>& x_rand,
  double eta)
{
  std::vector<double> x_new;

  if (Norm(x_nearest, x_rand) <= eta) {
    x_new = x_rand;
  } else {
    double m = (x_rand[1] - x_nearest[1]) / (x_rand[0] - x_nearest[0]);
    x_new.push_back(
      sign(x_rand[0] - x_nearest[0]) *
      std::sqrt((eta * eta) / ((m * m) + 1.0)) + x_nearest[0]);
    x_new.push_back(m * (x_new[0] - x_nearest[0]) + x_nearest[1]);

    if (x_rand[0] == x_nearest[0]) {
      x_new[0] = x_nearest[0];
      x_new[1] = x_nearest[1] + eta;
    }
  }
  return x_new;
}

// gridValue: occupancy value at world point Xp.
//   100 = occupied, -1 = unknown, 0 = free.
// Returns 100 (occupied) for out-of-bounds or invalid coordinates so the
// detector never treats an invalid cell as free or unknown.
static int gridValue(
  const nav_msgs::msg::OccupancyGrid& mapData,
  const std::vector<double>& Xp)
{
  double resolution = mapData.info.resolution;
  if (resolution <= 0.0) {
    return 100;
  }

  double Xstartx = mapData.info.origin.position.x;
  double Xstarty = mapData.info.origin.position.y;

  int col = static_cast<int>(std::floor((Xp[0] - Xstartx) / resolution));
  int row = static_cast<int>(std::floor((Xp[1] - Xstarty) / resolution));

  int width = static_cast<int>(mapData.info.width);
  int height = static_cast<int>(mapData.info.height);

  if (col < 0 || col >= width || row < 0 || row >= height) {
    return 100;
  }

  int indx = row * width + col;
  if (indx < 0 || indx >= static_cast<int>(mapData.data.size())) {
    return 100;
  }

  // map data is int8_t in ROS2 (signed on all platforms): -1 unknown, 0 free,
  // 100 occupied.  Cast to int so the comparison is safe and unambiguous.
  return static_cast<int>(mapData.data[indx]);
}

// ObstacleFree: walks from xnear toward xnew in small steps.
//   1  = free,  -1 = unknown (frontier),  0 = obstacle.
// Uses int (not char) for the status values so behaviour is identical on
// platforms where plain char is unsigned (e.g. ARM64).
static int ObstacleFree(
  std::vector<double> xnear,
  std::vector<double>& xnew,
  const nav_msgs::msg::OccupancyGrid& mapsub)
{
  double rez = static_cast<double>(mapsub.info.resolution) * 0.2;
  if (rez <= 0.0) {
    return 0;
  }

  int stepz = static_cast<int>(std::ceil(Norm(xnew, xnear) / rez));
  std::vector<double> xi = xnear;
  int obs = 0;
  int unk = 0;

  for (int c = 0; c < stepz; c++) {
    xi = Steer(xi, xnew, rez);

    if (gridValue(mapsub, xi) == 100) {
      obs = 1;
    }
    if (gridValue(mapsub, xi) == -1) {
      unk = 1;
      break;
    }
  }

  int out = 0;
  xnew = xi;
  if (unk == 1) {
    out = -1;
  }
  if (obs == 1) {
    out = 0;
  }
  if (obs != 1 && unk != 1) {
    out = 1;
  }
  return out;
}

// ---------------------------------------------------------------------------
// RRT detector node
// ---------------------------------------------------------------------------

class RRTDetector : public rclcpp::Node
{
public:
  RRTDetector() : rclcpp::Node("rrt_detector")
  {
    // --- Parameters ---
    eta_ = this->declare_parameter<double>("eta", 0.5);
    map_topic_ = this->declare_parameter<std::string>("map_topic", "/map");
    points_topic_ =
      this->declare_parameter<std::string>("points_topic", "/detected_points");
    global_frame_ =
      this->declare_parameter<std::string>("global_frame", "map");
    robot_frame_ =
      this->declare_parameter<std::string>("robot_frame", "base_link");
    int seed = this->declare_parameter<int>("random_seed", 0);
    double rate = this->declare_parameter<double>("rate", 100.0);
    max_tree_size_ =
      this->declare_parameter<int>("max_tree_size", 5000);

    if (rate <= 0.0) {
      rate = 100.0;
    }

    // Random number generator seeded by the configurable random_seed.
    // Replaces the original MTRand double generator.
    rng_.seed(static_cast<std::mt19937::result_type>(seed));
    uniform_dist_ = std::uniform_real_distribution<double>(0.0, 1.0);

    // --- Subscribers ---
    // The /map is typically published with transient-local durability
    // (latched).  Subscribe with a matching QoS so late-joining nodes
    // receive the most recent map immediately.
    rclcpp::QoS map_qos = rclcpp::QoS(rclcpp::KeepLast(1)).transient_local();
    map_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
      map_topic_, map_qos,
      std::bind(&RRTDetector::mapCallback, this, std::placeholders::_1));

    // --- Publishers ---
    detected_pub_ = this->create_publisher<geometry_msgs::msg::PointStamped>(
      points_topic_, 10);

    // Optional visualization marker (preserved from original).
    marker_pub_ = this->create_publisher<visualization_msgs::msg::Marker>(
      "~/rrt_shapes", 10);

    // --- TF ---
    tf_buffer_ = std::make_shared<tf2_ros::Buffer>(this->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);

    // --- Timer ---
    // One RRT iteration per callback — bounded work, never a blocking loop.
    std::chrono::duration<double> period(1.0 / rate);
    timer_ = this->create_wall_timer(
      std::chrono::duration_cast<std::chrono::nanoseconds>(period),
      std::bind(&RRTDetector::timerCallback, this));

    have_map_ = false;
    initialized_ = false;

    RCLCPP_INFO(
      this->get_logger(),
      "rrt_detector ready: map_topic=%s points_topic=%s eta=%.3f seed=%d",
      map_topic_.c_str(), points_topic_.c_str(), eta_, seed);
  }

  ~RRTDetector() override
  {
    // Stop dispatching on shutdown.
    if (timer_) {
      timer_->cancel();
    }
  }

private:
  // --- Map callback ---
  void mapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
  {
    mapData_ = *msg;
    have_map_ = true;
  }

  // --- Timer callback: one bounded RRT iteration ---
  void timerCallback()
  {
    if (!have_map_) {
      return;
    }
    if (mapData_.data.empty()) {
      return;
    }
    if (mapData_.info.resolution <= 0.0) {
      return;
    }

    if (!initialized_) {
      initializeRegion();
      if (!initialized_) {
        return;
      }
    }

    rrtStep();
  }

  // --- Initialize the sampling region and RRT seed ---
  void initializeRegion()
  {
    // Sampling region derived from the map metadata.
    init_map_x_ = mapData_.info.width * mapData_.info.resolution;
    init_map_y_ = mapData_.info.height * mapData_.info.resolution;
    Xstartx_ =
      mapData_.info.origin.position.x + init_map_x_ * 0.5;
    Xstarty_ =
      mapData_.info.origin.position.y + init_map_y_ * 0.5;

    // Seed the RRT at the robot pose (map -> base_link).  Fall back to the
    // map centre if TF is not yet available, but only mark initialized when
    // we have at least the centre.
    std::vector<double> seed;
    if (lookupRobotPose(seed)) {
      RCLCPP_INFO(
        this->get_logger(),
        "RRT seeded at robot pose (%.3f, %.3f)", seed[0], seed[1]);
    } else {
      RCLCPP_WARN(
        this->get_logger(),
        "TF for %s->%s unavailable; seeding RRT at map centre",
        global_frame_.c_str(), robot_frame_.c_str());
      seed.push_back(Xstartx_);
      seed.push_back(Xstarty_);
    }

    V_.clear();
    V_.push_back(seed);

    // Prepare the line marker for visualization.
    line_marker_.header.frame_id = normalizedFrameId();
    line_marker_.header.stamp = this->now();
    line_marker_.ns = "rrt_edges";
    line_marker_.id = 1;
    line_marker_.type = visualization_msgs::msg::Marker::LINE_LIST;
    line_marker_.action = visualization_msgs::msg::Marker::ADD;
    line_marker_.pose.orientation.w = 1.0;
    line_marker_.scale.x = 0.03;
    line_marker_.scale.y = 0.03;
    line_marker_.color.r = 9.0 / 255.0;
    line_marker_.color.g = 91.0 / 255.0;
    line_marker_.color.b = 236.0 / 255.0;
    line_marker_.color.a = 1.0;
    line_marker_.lifetime = rclcpp::Duration(0, 0);

    initialized_ = true;
  }

  // --- One RRT iteration (mirrors the original main loop body) ---
  void rrtStep()
  {
    // Sample a free point within the map bounds.
    double xr = (uniform_dist_(rng_) * init_map_x_) -
                (init_map_x_ * 0.5) + Xstartx_;
    double yr = (uniform_dist_(rng_) * init_map_y_) -
                (init_map_y_ * 0.5) + Xstarty_;

    std::vector<double> x_rand = {xr, yr};

    // Nearest vertex in the tree.
    std::vector<double> x_nearest = Nearest(V_, x_rand);

    // Steer toward the sample.
    std::vector<double> x_new = Steer(x_nearest, x_rand, eta_);

    // ObstacleFree:  1=free, -1=unknown(frontier), 0=obstacle
    int checking = ObstacleFree(x_nearest, x_new, mapData_);

    std::string frame_id = normalizedFrameId();

    if (checking == -1) {
      // Frontier detected — publish as a detection point.
      geometry_msgs::msg::PointStamped exploration_goal;
      exploration_goal.header.stamp = this->now();
      exploration_goal.header.frame_id = frame_id;
      exploration_goal.point.x = x_new[0];
      exploration_goal.point.y = x_new[1];
      exploration_goal.point.z = 0.0;
      detected_pub_->publish(exploration_goal);
    } else if (checking == 1) {
      // Free space — extend the tree.
      V_.push_back(x_new);

      // Add an edge to the visualization marker.
      geometry_msgs::msg::Point p;
      p.x = x_new[0];
      p.y = x_new[1];
      p.z = 0.0;
      line_marker_.points.push_back(p);
      p.x = x_nearest[0];
      p.y = x_nearest[1];
      p.z = 0.0;
      line_marker_.points.push_back(p);

      // Cap tree size to keep memory bounded.
      while (static_cast<int>(V_.size()) > max_tree_size_ && !V_.empty()) {
        V_.erase(V_.begin());
      }
    }

    // Publish the accumulated edge marker (bounded by the line list size).
    line_marker_.header.stamp = this->now();
    marker_pub_->publish(line_marker_);
  }

  // --- Look up the robot pose in the map frame via tf2 ---
  bool lookupRobotPose(std::vector<double>& pos)
  {
    try {
      geometry_msgs::msg::TransformStamped transform =
        tf_buffer_->lookupTransform(
          global_frame_, robot_frame_, tf2::TimePointZero);
      pos.push_back(transform.transform.translation.x);
      pos.push_back(transform.transform.translation.y);
      return true;
    } catch (const tf2::TransformException& ex) {
      return false;
    }
  }

  // --- Return the map frame id with any leading slash removed ---
  std::string normalizedFrameId() const
  {
    std::string frame_id = mapData_.header.frame_id;
    if (!frame_id.empty() && frame_id[0] == '/') {
      frame_id = frame_id.substr(1);
    }
    return frame_id;
  }

  // --- Parameters ---
  double eta_;
  std::string map_topic_;
  std::string points_topic_;
  std::string global_frame_;
  std::string robot_frame_;
  int max_tree_size_;

  // --- RRT state ---
  nav_msgs::msg::OccupancyGrid mapData_;
  bool have_map_;
  bool initialized_;
  std::vector<std::vector<double>> V_;
  double Xstartx_;
  double Xstarty_;
  double init_map_x_;
  double init_map_y_;
  std::mt19937 rng_;
  std::uniform_real_distribution<double> uniform_dist_;
  visualization_msgs::msg::Marker line_marker_;

  // --- ROS2 handles ---
  rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr map_sub_;
  rclcpp::Publisher<geometry_msgs::msg::PointStamped>::SharedPtr detected_pub_;
  rclcpp::Publisher<visualization_msgs::msg::Marker>::SharedPtr marker_pub_;
  std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
  rclcpp::TimerBase::SharedPtr timer_;
};

// ---------------------------------------------------------------------------
// main
// ---------------------------------------------------------------------------

int main(int argc, char** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<RRTDetector>());
  rclcpp::shutdown();
  return 0;
}
