# goose_rrt_exploration

RRT-based map exploration for a single differential-drive robot, migrated from
the **MIT `rrt_exploration` ROS1 package** (author **Hassan Umari**, MIT license,
<http://wiki.ros.org/rrt_exploration>) to **ROS2 Jazzy**.

This package does **not** recreate Nav2 or Gazebo. It expects an existing
Nav2 `NavigateToPose` action server, an existing SLAM `/map`
(`nav_msgs/OccupancyGrid`), and a tf2 `map -> base_link` transform. It samples
RRT frontiers, filters them, and dispatches one `NavigateToPose` goal at a time
to drive autonomous exploration.

## Attribution

Original algorithm and source:

> Hassan Umari, *rrt_exploration* — A ROS package that implements a multi-robot
> RRT-based map exploration algorithm. MIT License.
> <http://wiki.ros.org/rrt_exploration>

This ROS2 port preserves the original RRT sampling, frontier filtering, and
information-gain-minus-travel-cost assignment with hysteresis. No hardcoded
waypoints or mock physics are used.

## Nodes

| Component        | Language | Executable      | Role                                            |
-----------------|----------|----------------|------------------------------------------------|
| RRT detector    | C++      | `rrt_detector`  | Samples free-to-unknown frontiers, publishes raw candidate points. |
| Frontier filter | Python   | `filter.py`      | Removes invalid / occupied / low-information candidates. |
| Goal assigner   | Python   | `assigner.py`    | Scores frontiers (info gain - travel cost + hysteresis), dispatches Nav2 goals. |

`core.py` is installed beside the Python scripts and holds the pure-Python
algorithm helpers; it is importable **without** ROS or numpy.

## Topic / Action Contract

- **Input `/map`** — `nav_msgs/OccupancyGrid`, transient-local QoS supported.
- **`/detected_points`** — `geometry_msgs/PointStamped`, raw RRT frontiers.
- **`/filtered_points`** — `goose_rrt_exploration/PointArray`, filtered frontiers.
- **`navigate_to_pose`** — `nav2_msgs/NavigateToPose` action client (single active goal).
- **`/goose/exploration_status`** — `std_msgs/String` carrying JSON with
  `completed_goals`, `failed_goals`, and the currently `selected` goal, so an
  external runner can observe behavior.

## Generated Message

`goose_rrt_exploration/PointArray` retains the original `geometry_msgs/Point[] points` field.

## Parameters

| Parameter           | Default      | Description                                  |
|--------------------|-------------|----------------------------------------------|
| `map_topic`        | `/map`        | Input occupancy grid topic.                 |
| `points_topic`     | `/detected_points` | Raw frontier candidate topic.        |
| `frontiers_topic`  | `/filtered_points` | Filtered frontier topic.              |
| `global_frame`     | `map`         | World frame (used for goal headers).        |
| `robot_frame`      | `base_link`   | Robot base frame for tf2 lookup.             |
| `use_sim_time`     | `true`        | ROS sim time (set in launch, not redeclared).|
| `info_radius`      | `1.0`         | Information gain radius (m).                 |
| `info_multiplier`  | `3.0`         | Info gain weight vs. travel cost.             |
| `hysteresis_radius`| `3.0`         | Hysteresis neighborhood radius (m).          |
| `hysteresis_gain`  | `2.0`         | Hysteresis gain for nearby frontiers.        |
| `max_goals`        | `50`          | Max goals dispatched before stopping.        |
| `random_seed`      | `0`           | RRT RNG seed (0 = nondeterministic).         |

## Launch

```bash
ros2 launch goose_rrt_exploration exploration.launch.py
```

All parameters above are exposed as launch arguments, e.g.
`ros2 launch goose_rrt_exploration exploration.launch.py max_goals:=20 robot_frame:=base_footprint`.

## Design Notes

- **Bounded callbacks**: detector, filter, and assigner use timer/async
  callbacks; no blocking waits inside callbacks.
- **Single active goal**: the assigner keeps one `NavigateToPose` goal and uses
  `get_result_async`; rejected goals are retried after a bounded delay.
- **Nav2 readiness**: the assigner waits for the `bt_navigator` lifecycle state
  `active` (state 3) before dispatching; merely finding the action server is
  insufficient.
- **Map handling**: unknown and occupied cells are treated carefully; goals are
  never sent into occupied space. Output goal headers use the `/map` frame id
  normalized without a leading slash, with `orientation.w = 1.0`.
- **Shutdown**: the active goal is cancelled and dispatching stops on shutdown.
- **ARM64 safety**: frontier status values (-1/0/1) use explicit signed `int`
  types, never relying on plain `char` being signed.

## License

MIT (inherits the upstream `rrt_exploration` license).
