# Copyright (c) Hassan Umari, MIT license.
# ROS2 Jazzy launch for the goose_rrt_exploration package.
#
# Migrated from the MIT rrt_exploration ROS1 package. Launches the C++ RRT
# frontier detector (rrt_detector), the Python frontier filter, and the Python
# goal assigner for a single differential-drive robot that relies on an existing
# Nav2 NavigateToPose action server, an existing SLAM /map topic, and a tf2
# map -> base_link transform.

import os

from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    pkg_share = get_package_share_directory('goose_rrt_exploration')

    # ---- Common, configurable topics and frames ----
    map_topic = LaunchConfiguration('map_topic')
    points_topic = LaunchConfiguration('points_topic')
    frontiers_topic = LaunchConfiguration('frontiers_topic')
    global_frame = LaunchConfiguration('global_frame')
    robot_frame = LaunchConfiguration('robot_frame')
    use_sim_time = LaunchConfiguration('use_sim_time')

    # ---- Algorithm parameters ----
    info_radius = LaunchConfiguration('info_radius')
    info_multiplier = LaunchConfiguration('info_multiplier')
    hysteresis_radius = LaunchConfiguration('hysteresis_radius')
    hysteresis_gain = LaunchConfiguration('hysteresis_gain')
    max_goals = LaunchConfiguration('max_goals')
    random_seed = LaunchConfiguration('random_seed')
    rate_hz = LaunchConfiguration('rate_hz')

    declare_args = [
        DeclareLaunchArgument('map_topic', default_value='/map',
                              description='Input occupancy grid (nav_msgs/OccupancyGrid).'),
        DeclareLaunchArgument('points_topic', default_value='/detected_points',
                              description='Raw RRT frontier candidates (geometry_msgs/PointStamped).'),
        DeclareLaunchArgument('frontiers_topic', default_value='/filtered_points',
                              description='Filtered frontiers (goose_rrt_exploration/PointArray).'),
        DeclareLaunchArgument('global_frame', default_value='map',
                              description='Global/world frame id.'),
        DeclareLaunchArgument('robot_frame', default_value='base_link',
                              description='Robot base frame id.'),
        DeclareLaunchArgument('use_sim_time', default_value='true',
                              description='Use ROS sim time.'),
        DeclareLaunchArgument('info_radius', default_value='1.0',
                              description='Information gain radius (m).'),
        DeclareLaunchArgument('info_multiplier', default_value='3.0',
                              description='Information gain multiplier over travel cost.'),
        DeclareLaunchArgument('hysteresis_radius', default_value='3.0',
                              description='Hysteresis radius (m).'),
        DeclareLaunchArgument('hysteresis_gain', default_value='2.0',
                              description='Hysteresis gain applied to nearby frontiers.'),
        DeclareLaunchArgument('max_goals', default_value='50',
                              description='Maximum goals to dispatch before stopping.'),
        DeclareLaunchArgument('random_seed', default_value='0',
                              description='RRT RNG seed (0 = nondeterministic).'),
        DeclareLaunchArgument('rate_hz', default_value='1.0',
                              description='Detector timer rate (Hz).'),
    ]

    # Common parameters shared by all three nodes.
    common_params = {
        'use_sim_time': use_sim_time,
        'map_topic': map_topic,
        'global_frame': global_frame,
    }

    # C++ RRT frontier detector.
    detector = Node(
        package='goose_rrt_exploration',
        executable='rrt_detector',
        name='rrt_detector',
        output='screen',
        parameters=[common_params, {
            'points_topic': points_topic,
            'robot_frame': robot_frame,
            'random_seed': random_seed,
            'rate_hz': rate_hz,
        }],
    )

    # Python frontier filter.
    filter_node = Node(
        package='goose_rrt_exploration',
        executable='filter.py',
        name='frontier_filter',
        output='screen',
        parameters=[common_params, {
            'points_topic': points_topic,
            'frontiers_topic': frontiers_topic,
            'info_radius': info_radius,
        }],
    )

    # Python goal assigner (talks to Nav2 NavigateToPose).
    assigner = Node(
        package='goose_rrt_exploration',
        executable='assigner.py',
        name='goal_assigner',
        output='screen',
        parameters=[common_params, {
            'frontiers_topic': frontiers_topic,
            'robot_frame': robot_frame,
            'info_radius': info_radius,
            'info_multiplier': info_multiplier,
            'hysteresis_radius': hysteresis_radius,
            'hysteresis_gain': hysteresis_gain,
            'max_goals': max_goals,
        }],
    )

    return LaunchDescription(declare_args + [detector, filter_node, assigner])
