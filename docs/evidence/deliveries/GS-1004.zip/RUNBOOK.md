# ROS 1 frontier exploration to ROS 2 Jazzy with a Gazebo mission

TEST engagement. No real customer or revenue is implied.

The source/ directory contains the verified implementation. Build using target_build from workspace-contract.json. All commands are argv arrays executed in the source directory. report.json records the checks and limitations. Preserve the original system before deployment. Production cutover and data reconciliation require a separately approved plan.
