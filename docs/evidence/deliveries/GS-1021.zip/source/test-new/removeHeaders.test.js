'use strict'

const { test } = require('node:test')
const assert = require('node:assert')
const Fastify = require('../fastify.js')

test('removeHeaders removes a batch case-insensitively and returns the same reply', async (t) => {
  const fastify = Fastify()
  t.after(() => fastify.close())

  fastify.get('/', async (req, reply) => {
    reply.header('x-foo', 'foo')
    reply.header('x-bar', 'bar')
    reply.header('X-Baz', 'baz')
    const returned = reply.removeHeaders(['X-FOO', 'x-bar'])
    assert.strictEqual(returned, reply, 'should return the same reply instance')
    assert.strictEqual(reply.getHeader('x-baz'), 'baz')
  })

  const res = await fastify.inject({ method: 'GET', url: '/' })
  assert.strictEqual(res.statusCode, 200)
  assert.strictEqual(res.headers['x-foo'], undefined)
  assert.strictEqual(res.headers['x-bar'], undefined)
  assert.strictEqual(res.headers['x-baz'], 'baz')
})

test('removeHeaders is a no-op on an empty array', async (t) => {
  const fastify = Fastify()
  t.after(() => fastify.close())

  fastify.get('/', async (req, reply) => {
    reply.header('x-foo', 'foo')
    const returned = reply.removeHeaders([])
    assert.strictEqual(returned, reply)
    assert.strictEqual(reply.getHeader('x-foo'), 'foo')
  })

  const res = await fastify.inject({ method: 'GET', url: '/' })
  assert.strictEqual(res.headers['x-foo'], 'foo')
})

test('removeHeaders treats duplicate and missing names as harmless', async (t) => {
  const fastify = Fastify()
  t.after(() => fastify.close())

  fastify.get('/', async (req, reply) => {
    reply.header('x-foo', 'foo')
    reply.removeHeaders(['x-foo', 'x-foo', 'x-missing', 'X-FOO'])
    assert.strictEqual(reply.getHeader('x-foo'), undefined)
  })

  const res = await fastify.inject({ method: 'GET', url: '/' })
  assert.strictEqual(res.headers['x-foo'], undefined)
})

test('removeHeaders throws TypeError on non-array input without mutating headers', async (t) => {
  const fastify = Fastify()
  t.after(() => fastify.close())

  fastify.get('/', async (req, reply) => {
    reply.header('x-foo', 'foo')
    const nonArrays = ['string', 42, {}, null, undefined, true, Symbol('s')]
    for (const input of nonArrays) {
      assert.throws(() => reply.removeHeaders(input), TypeError)
      assert.strictEqual(reply.getHeader('x-foo'), 'foo', 'header unchanged after non-array input: ' + String(input))
    }
  })

  const res = await fastify.inject({ method: 'GET', url: '/' })
  assert.strictEqual(res.statusCode, 200)
})

test('removeHeaders throws TypeError on any non-string element without mutating headers', async (t) => {
  const fastify = Fastify()
  t.after(() => fastify.close())

  fastify.get('/', async (req, reply) => {
    reply.header('x-foo', 'foo')
    reply.header('x-bar', 'bar')
    assert.throws(() => reply.removeHeaders(['x-foo', 42, 'x-bar']), TypeError)
    assert.strictEqual(reply.getHeader('x-foo'), 'foo')
    assert.strictEqual(reply.getHeader('x-bar'), 'bar')
  })

  const res = await fastify.inject({ method: 'GET', url: '/' })
  assert.strictEqual(res.statusCode, 200)
})

test('removeHeaders is fluent / chainable', async (t) => {
  const fastify = Fastify()
  t.after(() => fastify.close())

  fastify.get('/', async (req, reply) => {
    reply.header('x-foo', 'foo')
    reply.header('x-bar', 'bar')
    reply.removeHeaders(['x-foo']).header('x-baz', 'baz')
    assert.strictEqual(reply.getHeader('x-foo'), undefined)
    assert.strictEqual(reply.getHeader('x-bar'), 'bar')
    assert.strictEqual(reply.getHeader('x-baz'), 'baz')
  })

  const res = await fastify.inject({ method: 'GET', url: '/' })
  assert.strictEqual(res.headers['x-foo'], undefined)
  assert.strictEqual(res.headers['x-bar'], 'bar')
  assert.strictEqual(res.headers['x-baz'], 'baz')
})
